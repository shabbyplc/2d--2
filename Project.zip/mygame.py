import game_framework

# fill here
import start_state

game_framework.run(start_state)